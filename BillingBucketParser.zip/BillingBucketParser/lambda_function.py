# Import the necessary modules
# CSV for handling CSV files, boto3 for SDK, datetime for date operators
import csv
import boto3
from datetime import datetime

def lambda_handler(event, context):
    
    # Initialize the S3 resource using boto3
    s3 = boto3.resource('s3')
    
    # Extract the bucket name and CSV file name from the 'event' input
    billing_bucket = event['Records'][0]['s3']['bucket']['name']
    csv_file = event['Records'][0]['s3']['object']['key']
    
    # Define the name of the error bucket where you want to copy the erroneous CSV file
    error_bucket = 'dct-billing-error-x'

    # Download the CSV file from S3, read the content, decode from bytes to string, and split the content by line
    obj = s3.Object(billing_bucket, csv_file)
    data = obj.get()['Body'].read().decode('utf-8').splitlines()
    
    # Initialize a flag (error_found) to false. We'll set this flag to true when we find an error
    error_found = False
    
    # Define valid product lines and valid currencies
    valid_product_lines = ['Bakery', 'Meat', 'Dairy']
    valid_currencies = ['USD', 'MXN', 'CAD']
    
    # Read the CSV content line by line using Python's csv reader. Ignore the header line (data[1:])
    for row in csv.reader(data[1:], delimiter=','):
        # for each row, extract the product line, currency, bill amount, and date from the specific columns
        
        date = row[6]
        product_line = row[4]
        currency = row[7]
        bill_amount = float(row[8])
        
        # check if the product line is valid, if not, set error flag to true and print an error message
        if product_line not in valid_product_lines:
            error_found = True
            print(f"Error in record {row[0]}: Unrecognized product: {product_line}.")
            break
        # check if the currency is valid, if not, set error flag to true and print an error message
        if currency not in valid_currencies:
            error_found = True
            print(f"Error in record {row[0]}: Unrecognized currency: {currency}.")
            break
            
        # check if the bill amount is negative, if so, set error flag to true and print an error message
        
        #  check if the date is in the correct format ('%Y-&m-%d') , if not, set error flag to true and print an error message
        try:
            datetime.strptime(date,'%Y-%m-%d')
        except ValueError:
            error_found = True
            print(f"Error in record {row[0]}: incorrect date format: {date}.")
            break
            
            
    # After checking all rows, if an error is found, copy the CVS File to the error bucket and delete it from the original bucket
    if error_found:
        copy_source = {
            'Bucket' : billing_bucket,
            'Key' : csv_file
        }
        try:
            s3.meta.client.copy(copy_source, error_bucket, csv_file)
            print(f"Move erronous file to: {error_bucket}")
            s3.Object(billing_bucket, csv_file).delete()
            print("Delete original file from bucket")
            
        # Handle any exception that may occur while moving the file, and print the error message
        except Exception as e:
            print(f"Error while moving file: {str(e)}.")
    # if no errors were found, return a success message with status code 200 and a body message indicating that no errors were found
    else:
        return {
            'statusCode': 200,
            'body': 'Hello from Lambda!'
    }
